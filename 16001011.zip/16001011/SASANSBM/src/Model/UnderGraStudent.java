
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class UnderGraStudent extends Student {
    private String Qualification;
    private String Result;
    String SQLAddStudent = "INSERT INTO StudentUnder(Stu_id,F_name,L_name,Gmail,Gender,Dob,Address,Qualification,Result,Con_number,Reg_DegreeId)"+"VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    String SQLUpdateStudent = "UPDATE StudentUnder SET F_name=?,L_name=?,Gmail=?,Gender=?,Dob=?,Address=?,Qualification=?,Result=?,Con_number=?,Reg_DegreeId=? WHERE Stu_id= ?";
    String SQLDeleteStudent = "DELETE FROM  StudentUnder WHERE Stu_id=?";
    
    public UnderGraStudent(String Stu_id,String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Con_number,String Reg_DegreeId,String Qualification,String Result){
       super(Stu_id,F_name,L_name,Gmail,Gender,Dob,Address,Con_number,Reg_DegreeId);
        this.Qualification=Qualification;
        this.Result=Result;
    }
    public UnderGraStudent(){
        
    }
     public String get_Qualification(){
       return Qualification;
   }
   public void Set_Qualification(String Qualification){
       this.Qualification=Qualification;
   }
   
    public String get_Result(){
       return Result;
   }
   public void Set_Result(String Result){
       this.Result=Result;
   }
   
   public void AddStudent(String Stu_id,String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Qualification,String Result,String Con_number,String Reg_DegreeId ) throws SQLException{
      Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLAddStudent);
            stmt.setString(1, Stu_id);
            stmt.setString(2, F_name);
            stmt.setString(3, L_name);
            stmt.setString(4, Gmail);
            stmt.setString(5, Gender);
            stmt.setString(6, Dob);
            stmt.setString(7, Address);
            stmt.setString(8, Qualification);
            stmt.setString(9, Result);
            stmt.setString(10, Con_number);
            stmt.setString(11,Reg_DegreeId);
            
            stmt.execute();  
   }

    public void UpdateStudent(String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Qualification,String Result,String Con_number,String Reg_DegreeId,String Stu_id) throws SQLException{
       
         Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLUpdateStudent);
            
            stmt.setString(1, F_name);
            stmt.setString(2, L_name);
            stmt.setString(3, Gmail);
            stmt.setString(4, Gender);
            stmt.setString(5, Dob);
            stmt.setString(6, Address);
            stmt.setString(7, Qualification);
            stmt.setString(8, Result);
            stmt.setString(9, Con_number);
            stmt.setString(10,Reg_DegreeId);
            stmt.setString(11, Stu_id);
             
            
            stmt.execute();
        
    }
    public void DeleteStudent(String Stu_id) throws SQLException{
        Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLDeleteStudent);
             stmt.setString(1,Stu_id);
            
            stmt.execute();
    }
}
