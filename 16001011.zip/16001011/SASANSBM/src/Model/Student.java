
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Student {
   private String Stu_id;
   private String F_name;
   private String L_name;
   private String Gmail;
   private String Gender;
   private String Dob;
   private String Address;
   private String Con_number;
   private String Reg_DegreeId;
   private static String SQLEnrollSub = "INSERT INTO EnrolleSubject(Sub_id,Stu_id,Level_no,Semester_no)"+"VALUES(?,?,?,?)";
   private static String SQLDeleteEnro="DELETE FROM EnrolleSubject WHERE Stu_id=? AND Level_no=? AND Semester_no=?";
   private static String SqlAddAssignment="INSERT INTO GiveAssignment(Sub_id,Assignment_num,Stu_id,Result)"+"VALUES(?,?,?,?)";
   private static String SqlAddExam="INSERT INTO GiveExam(Sub_id,Stu_id,Result)"+"VALUES(?,?,?)";
   private static String SqlExamResult="SELECT Sub_id,Stu_id,Result FROM `giveexam` WHERE Stu_id=?";
   private static String SqlAssignmentResult="SELECT Sub_id,Assignment_num,Stu_id,Result FROM `giveassignment` WHERE Stu_id=?";
   
   private static String SqlExamR="SELECT Result FROM `giveexam` WHERE Stu_id=? AND Sub_id=?";
   private static String SqlAssignmentR="SELECT Result FROM `giveassignment` WHERE Sub_id=? AND Assignment_num=? AND Stu_id=?";
   
   private static String SQLgetEmailAddress1="SELECT Gmail FROM StudentUnder WHERE Stu_id=?";
   private static String SQLgetEmailAddress2="SELECT Gmail FROM StudentPost WHERE Stu_id=?";
           
   public Student(String Stu_id,String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Con_number,String Reg_DegreeId){
    this.Stu_id=Stu_id;
    this.F_name =F_name;
    this.L_name=L_name;
    this.Gmail=Gmail;
    this.Gender=Gender;
    this.Dob=Dob;
    this.Address=Address;
    this.Con_number=Con_number;
    this.Reg_DegreeId=Reg_DegreeId;
   }
   public Student(){
       
   }
   public String get_Stu_id(){
       return Stu_id;
   }
   public void Set_Stu_id(String Stu_id){
       this.Stu_id=Stu_id;
   }
   public String get_F_name(){
       return F_name;
   }
   public void Set_F_name(String name){
       this.F_name=name;
   }
   
   public String get_L_name(){
       return L_name;
   }
   public void Set_L_name(String L_name){
       this.L_name=L_name;
   }
   
   public String get_Dob(){
       return Dob;
   }
   public void Set_Dob(String Dob){
       this.Dob=Dob;
   }
   
   public String get_Address(){
       return Address;
   }
   public void Set_Address(String Address){
       this.F_name=Address;
   }
   
   public String get_Con_number(){
       return Con_number;
   }
   public void Set_Con_number(String Con_number){
       this.Con_number=Con_number;
   }
   
   public String get_Reg_DegreeId(){
       return Reg_DegreeId;
   }
   public void Set_Reg_DegreeId(String Reg_DegreeId){
       this.Reg_DegreeId=Reg_DegreeId;
   }
   
   public String get_Gender(){
       return Gender;
   }
   public void Set_Gender(String Gender){
       this.Gender=Gender;
   }
   
   public String get_Gmail(){
       return Gmail;
   }
   public void Set_Gmail(String Gmail){
       this.Gmail=Gmail;
   }
   public static void Enroll_Subject(String Sub_id,String Stu_id,String Level_no,String Semester_no) throws SQLException{
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLEnrollSub);
            Sub_id=Sub_id.substring(Sub_id.indexOf("(") + 1, Sub_id.indexOf(")"));
            stmt.setString(1,Sub_id) ;
            stmt.setString(2,Stu_id);
            stmt.setString(3,Level_no);
            stmt.setString(4,Semester_no);
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
   }
  
   
   public static void Delect_Enrollment(String Stu_id,String Level_no,String Semester_no){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLDeleteEnro);
            stmt.setString(1,Stu_id);
            stmt.setString(2,Level_no);
            stmt.setString(3,Semester_no);
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
       
   }
   
   public static void Add_Assignment_Result(String Sub_id,String Assignment_num,String Stu_id,String Result){
         Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SqlAddAssignment);
            stmt.setString(1,Sub_id);
            stmt.setString(2, Assignment_num);
            stmt.setString(3,Stu_id);
            stmt.setString(4,Result);
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
   }
 public static void Add_Axam_Result(String Sub_id,String Stu_id,String Result){
         Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SqlAddExam);
            stmt.setString(1,Sub_id);
            stmt.setString(2, Stu_id);
            stmt.setString(3,Result);
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
   }
 //Send email Exam
 public static String Get_Exam_Result(String St_id){
     ResultSet rs = null;
     ResultSet rs2 = null;
     StringBuffer buffer = new StringBuffer();
     try{
       Connection conn =JavaCreateDatabaseConnection.getconnection();
       PreparedStatement stmt = conn.prepareStatement(SqlExamResult);
       stmt.setString(1,St_id);
       rs=stmt.executeQuery();
       rs.next();
       
       buffer.append("#### NSBM RESULT CENTER ####\n");
       buffer.append("#######  EXAM RESULT  #######\n");
       buffer.append("Student id -> "+rs.getString("Stu_id")+"\n");
       
       rs2=GetCreditsFees.Values(rs.getString("Sub_id"));
       rs2.next();
       
       buffer.append("Subject -> " + rs2.getString("Sub_name")+" "+rs.getString("Result")+"\n");
       rs2.close();
       while(rs.next()){
           rs2=GetCreditsFees.Values(rs.getString("Sub_id"));
           rs2.next();
           buffer.append("Subject -> " + rs2.getString("Sub_name")+" "+rs.getString("Result")+"\n");    
       }
       buffer.append("****#######$$$$$$$$$$#######*****\n");
     }
     catch(SQLException e){
         System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e); 
     }
    return buffer.toString();
 }  
//send email Assignment   
public static String Get_Assignment_Result(String St_id){
     ResultSet rs = null;
     ResultSet rs2 = null;
     StringBuffer buffer = new StringBuffer();
     try{
         Connection conn =JavaCreateDatabaseConnection.getconnection();
       PreparedStatement stmt = conn.prepareStatement(SqlAssignmentResult);
       stmt.setString(1,St_id);
       rs=stmt.executeQuery();
       rs.next();
       
       buffer.append("#### NSBM RESULT CENTER ####\n");
       buffer.append("####  ASSIGMENT RESULT  ####\n");
       buffer.append("Student id -> "+rs.getString("Stu_id")+"\n");
       
       rs2=GetCreditsFees.Values(rs.getString("Sub_id"));
       rs2.next();
       buffer.append("Subject -> " + rs2.getString("Sub_name")+" Assignment No -> "+rs.getString("Assignment_num")+"\n"+rs.getString("Result")+"\n");
       rs2.close();
       
       while(rs.next()){
           rs2=GetCreditsFees.Values(rs.getString("Sub_id"));
           rs2.next();
           buffer.append("Subject -> " + rs2.getString("Sub_name")+" Assignment No -> "+rs.getString("Assignment_num")+"\n"+rs.getString("Result")+"\n");    
       }
        buffer.append("****#######$$$$$$$$$$#######*****\n");
     }
     catch(SQLException e){
         System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e); 
     }
   return buffer.toString();  
}
//Send email ExamR   
public static String ExamR(String Stu_id,String Sub_id ) throws SQLException{
     ResultSet rs = null;
     Connection conn=null;
     PreparedStatement stmt=null;        
     String ss = "Result has not been Added yet ...";
    
     try{
       conn =JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SqlExamR);
       stmt.setString(1,Stu_id);
       stmt.setString(2,Sub_id);
       rs=stmt.executeQuery();
       rs.next();
       ss=rs.getString("Result");
            

     }
     catch(SQLException e){
         System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e); 
     }
     
   finally{
         rs.close();
         stmt.close();
         conn.close();
         return ss;
          
           }
} 
//Send email AssignmentR  
public static String AssignmentR(String Sub_id,String Assignment_num,String Stu_id) throws SQLException{
    ResultSet rs = null;
     Connection conn=null;
     PreparedStatement stmt=null;        
     String ss = "Result has not been Added yet ...";
    
     try{
       conn =JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SqlAssignmentR);
       
       stmt.setString(1,Sub_id);
       stmt.setString(2,Assignment_num);
       stmt.setString(3,Stu_id);
      
       rs=stmt.executeQuery();
       rs.next();
       ss=rs.getString("Result");
            

     }
     catch(SQLException e){
         System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e); 
     }
     
   finally{
         rs.close();
         stmt.close();
         conn.close();
         return ss;
          
           } 
}

public static String getEmailAddress(String Stu_id) throws SQLException{
     ResultSet rs1 = null;
     ResultSet rs2 = null;
     Connection conn=null;
     PreparedStatement stmt1=null;
     PreparedStatement stmt2=null;
     conn =JavaCreateDatabaseConnection.getconnection();
     String ss = "";
    
     try{
       
       
       stmt1 = conn.prepareStatement(SQLgetEmailAddress1);
       stmt1.setString(1,Stu_id);
       rs1=stmt1.executeQuery();
       
       
       if(rs1.next()){
           
            ss=rs1.getString("Gmail");
            rs1.close();
            stmt1.close();
       }
       else{
          stmt2 = conn.prepareStatement(SQLgetEmailAddress2);
          stmt2.setString(1,Stu_id);
          rs2=stmt2.executeQuery();
          rs2.next();
          ss=rs2.getString("Gmail");
          rs2.close();
          stmt2.close();
       }
     }
     catch(SQLException e){
         System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e); 
     }
     
     
   finally{
         
        
         conn.close();
         return ss;
          
           } 
}
}
