
package Model;

import Model.JavaCreateDatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//GetCreditsFees.Values(ccvc).next.getString("Sub_name");

public class GetCreditsFees {

private static String SQLAddSubject = "INSERT INTO Subject(Sub_id,Sub_name,Sub_credits,Sub_fee)"+"VALUES(?,?,?,?)";   
private static final String SQLforgetCreditandFees = "SELECT Sub_credits,Sub_fee,Sub_name FROM Subject WHERE Sub_id=?";
private static String SQLUpdateSubject = "UPDATE Subject SET Sub_name= ?,Sub_credits= ?,Sub_fee=? WHERE Sub_id= ?";
private static ResultSet rs = null;
private static Connection conn =null;
private static PreparedStatement stmt;
//This method return result set --> Input :(Subject Id)
//                              --> Output :(Num of Credits , Fees) 
    public static ResultSet Values(String SubId){
        try {
            conn=JavaCreateDatabaseConnection.getconnection();
            stmt = conn.prepareStatement(SQLforgetCreditandFees,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            stmt.setString(1, SubId);
            rs=stmt.executeQuery();
            
        } catch (SQLException e) {
             System.out.println(e.getMessage());
             JOptionPane.showMessageDialog(null, e);
        }
         return rs;
    }
    
    public void AddSubject(String Sub_id,String Sub_name,String Sub_credits,String Sub_fee) throws SQLException{
        
        conn = JavaCreateDatabaseConnection.getconnection();
        stmt = conn.prepareStatement(SQLAddSubject);
            stmt.setString(1,Sub_id) ;
            stmt.setString(2,Sub_name);
            stmt.setString(3,Sub_credits);
            stmt.setString(4,Sub_fee);
            stmt.execute();
   
            
    }
    
    public void UpdateSubject(String Sub_name,String Sub_credits,String Sub_fee,String Sub_id) throws SQLException{
        conn = JavaCreateDatabaseConnection.getconnection();
        stmt = conn.prepareStatement(SQLUpdateSubject);
            
            stmt.setString(1, Sub_name);
            stmt.setString(2, Sub_credits);
            stmt.setString(3, Sub_fee);
            stmt.setString(4, Sub_id);
            
            stmt.execute();
    }
}
