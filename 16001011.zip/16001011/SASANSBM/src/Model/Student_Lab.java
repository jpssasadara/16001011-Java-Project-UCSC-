
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Student_Lab {
    
    public Student_Lab(String Stu_id,String L_id,String Start_time,String End_time,String Day){
            this.Stu_id=Stu_id;
            this.L_id=L_id;
            this.Start_time=Start_time;
            this.End_time=End_time;
            this.Day=Day;
    }
   
    public String getStu_id() {
        return Stu_id;
    }

   
    public void setStu_id(String Stu_id) {
        this.Stu_id = Stu_id;
    }

    
    public String getL_id() {
        return L_id;
    }

   
    public void setL_id(String L_id) {
        this.L_id = L_id;
    }

   
    public String getStart_time() {
        return Start_time;
    }

    
    public void setStart_time(String Start_time) {
        this.Start_time = Start_time;
    }

   
    public String getEnd_time() {
        return End_time;
    }

    
    public void setEnd_time(String End_time) {
        this.End_time = End_time;
    }

    
    public String getDay() {
        return Day;
    }

    
    public void setDay(String Day) {
        this.Day = Day;
    }
    
     //insert Student_Lab details 
     public static void insert_Ins(String Stu_id,String L_id,String Start_time,String End_time,String Day){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert_Ins);
           
            stmt.setString(1,Stu_id);
            stmt.setString(2,L_id);
            stmt.setString(3,Start_time);
            stmt.setString(4,End_time);
            stmt.setString(5,Day);
           
           
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    //delete Student_Lab details
    public static void delete_Ins(String Stu_id,String L_id,String Start_time,String End_time,String Day){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete_Ins);
           
            stmt.setString(1,Stu_id);
            stmt.setString(2,L_id);
            stmt.setString(3,Start_time);
            stmt.setString(4,End_time);
            stmt.setString(5,Day);
            
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
     //update Student_Lab details
    public static void update_Ins(String Stu_id,String L_id,String Start_time,String End_time,String Day){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLupdate_Ins);
           
            
            stmt.setString(1,L_id);
            stmt.setString(2,Start_time);
            stmt.setString(3,End_time);
            stmt.setString(4,Day);
            stmt.setString(5,Stu_id);
           
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
   
     //update Student_Lab details
    public static int Constraint_Lab(String L_id) throws SQLException{
       Connection conn = null;
       PreparedStatement stmt = null;
       ResultSet rs =null;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLcount_stu_lab);
          
                stmt.setString(1,L_id);
                rs = stmt.executeQuery();
                rs.next();
                return rs.getInt("COUNT(L_id)");
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            return 50;
            } 
            finally{
                conn.close();
                stmt.close();
       }
    } 
    
    
 private static String SQLinsert_Ins = "INSERT INTO Understu_lab_time(Stu_id,L_id,Start_time,End_time,Day)"+"VALUES(?,?,?,?,?)";
 private static String SQLdelete_Ins = "DELETE FROM Understu_lab_time WHERE Stu_id=? AND L_id=? AND Start_time=? AND End_time=? AND Day=?";
 private static String SQLupdate_Ins = "UPDATE Understu_lab_time SET L_id=?,Start_time=?,End_time=?,Day=? WHERE Stu_id=?";
 
 private static String SQLcount_stu_lab = "SELECT COUNT(L_id) FROM `Understu_lab_time` WHERE L_id=?";
         
 private String Stu_id;
 private String L_id;
 private String Start_time;
 private String End_time;
 private String Day;
 
}
