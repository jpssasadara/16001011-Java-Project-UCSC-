
package Model;

//for enter data in to jtable
public class StudentEnrolledSubject_forJtable {
    private String level_no;
    private String sem_num;
    private String Sub_id;
    private String Sub_name;
    private String Num_Credit;
    private String fees;
    
    public StudentEnrolledSubject_forJtable(String level_no,String sem_num,String Sub_id,String Sub_name,String Num_Credit,String fees ){
        this.level_no = level_no;
        this.sem_num = sem_num;
        this.Sub_id = Sub_id;
        this.Sub_name=Sub_name;
        this.Num_Credit=Num_Credit;
        this.fees=fees;
        
        
    }
    
    public String getLevel_no() {
        return level_no;
    }

    
    public void setLevel_no(String level_no) {
        this.level_no = level_no;
    }

   
    public String getSem_num() {
        return sem_num;
    }

    
    public void setSem_num(String sem_num) {
        this.sem_num = sem_num;
    }

    
    public String getSub_id() {
        return Sub_id;
    }

    
    public void setSub_id(String Sub_id) {
        this.Sub_id = Sub_id;
    }

    
    public String getSub_name() {
        return Sub_name;
    }

    
    public void setSub_name(String Sub_name) {
        this.Sub_name = Sub_name;
    }

    
    public String getNum_Credit() {
        return Num_Credit;
    }

    
    public void setNum_Credit(String Num_Credit) {
        this.Num_Credit = Num_Credit;
    }

    
    public String getFees() {
        return fees;
    }

    
    public void setFees(String fees) {
        this.fees = fees;
    }
   
}
