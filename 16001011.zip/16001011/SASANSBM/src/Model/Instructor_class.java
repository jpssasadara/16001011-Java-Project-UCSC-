
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Instructor_class {

    public Instructor_class(String Ins_id,String Ins_name,String Sub_id){
        this.Ins_id=Ins_id;
        this.Ins_name=Ins_name;
        this.Sub_id=Sub_id;
    }
    
    public Instructor_class(String Ins_id,String Ins_name){
        this.Ins_id=Ins_id;
        this.Ins_name=Ins_name;
    }

    
    
    public String getIns_id() {
        return Ins_id;
    }

    
    public void setIns_id(String Ins_id) {
        this.Ins_id = Ins_id;
    }

    
    public String getIns_name() {
        return Ins_name;
    }

   
    public void setIns_name(String Ins_name) {
        this.Ins_name = Ins_name;
    }

    
    public String getSub_id() {
        return Sub_id;
    }

   
    public void setSub_id(String Sub_id) {
        this.Sub_id = Sub_id;
    }
    
    //insert Instructor details 
     public static void insert_Ins(String Ins_id,String Ins_name){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert_Ins);
           
            stmt.setString(1,Ins_id);
            stmt.setString(2,Ins_name);
           
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    //delete Instructor details
    public static void delete_Ins(String Ins_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete_Ins);
           
            stmt.setString(1,Ins_id);
            
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
     //update Instructor details
    public static void update_Ins(String Ins_name,String Ins_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLupdate_Ins);
           
            
            stmt.setString(1,Ins_name);
            stmt.setString(2,Ins_id);
           
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
    //Add Subjects for instructor 
     public static void insert_sub(String Ins_id,String Sub_id){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert_sub);
           
            stmt.setString(1,Ins_id);
            stmt.setString(2,Sub_id);
           
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    //delete Instructor's subjects 
    public static void delete_sub(String Ins_id,String Sub_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete_sub);
           
            stmt.setString(1,Ins_id);
            stmt.setString(2,Sub_id);
            
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
 private String Ins_id;
 private String Ins_name;
 private String Sub_id;
 
 private static String SQLinsert_Ins = "INSERT INTO Instructor(Ins_id,Ins_name)"+"VALUES(?,?)";
 private static String SQLdelete_Ins = "DELETE FROM Instructor WHERE Ins_id=?";
 private static String SQLupdate_Ins = "UPDATE Instructor SET Ins_name=? WHERE Ins_id=?";

 
 private static String SQLinsert_sub="INSERT INTO Subject_instructor(Ins_id,Sub_id) VALUES(?,?)";
 private static String SQLdelete_sub="DELETE FROM Subject_instructor WHERE Ins_id=? AND Sub_id=?";

}
