/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author suravi
 */
public class Labclass {

    public Labclass(String L_id,String L_name){
        this.L_id=L_id;
        this.L_name=L_name;
    }
    public String getL_id() {
        return L_id;
    }

   
    public void setL_id(String L_id) {
        this.L_id = L_id;
    }

   
    public String getL_name() {
        return L_name;
    }

   
    public void setL_name(String L_name) {
        this.L_name = L_name;
    }
   

   
    public static void lab_insert(String L_id,String L_name){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert);
           
            stmt.setString(1,L_id) ;
            stmt.setString(2,L_name) ;
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
    }
    public static void lab_delete(String L_id){
      Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete);
           
            stmt.setString(1,L_id) ;
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
  private String L_id; 
  private String L_name;
  private static  String SQLinsert = "INSERT INTO Lab(L_id,L_name)"+"VALUES(?,?)";
  private static String SQLdelete = "DELETE FROM Lab WHERE L_id=?";
    
}
