
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Lecture_class {
    
    public Lecture_class(String Lec_id,String Lec_name,String Sub_id){
         this.Lec_id= Lec_id;
         this.Lec_name=Lec_name;
         this.Sub_id=Sub_id;
    }

    public String getLec_id() {
        return Lec_id;
    }

    
    public void setLec_id(String Lec_id) {
        this.Lec_id = Lec_id;
    }

    public String getLec_name() {
        return Lec_name;
    }

    
    public void setLec_name(String Lec_name) {
        this.Lec_name = Lec_name;
    }

   
    public String getSub_id() {
        return Sub_id;
    }

    
    public void setSub_id(String Sub_id) {
        this.Sub_id = Sub_id;
    }
    
    //insert lectures details
     public static void insert(String Lec_id,String Lec_name,String Sub_id){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert);
           
            stmt.setString(1,Lec_id);
            stmt.setString(2,Lec_name);
            stmt.setString(3,Sub_id);
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    //delete lecture details
    public static void delete(String Lec_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete);
           
            stmt.setString(1,Lec_id);
            
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    //update lecture details
    public static void update(String Lec_id,String Lec_name,String Sub_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLupdate);
           
            
            stmt.setString(1,Lec_name);
            stmt.setString(2,Sub_id);
            stmt.setString(3,Lec_id);
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
    
    private String Lec_id;
    private String Lec_name;
    private String Sub_id;
   private static String SQLinsert = "INSERT INTO Lecture(Lec_id,Lec_name,Sub_id)"+"VALUES(?,?,?)";
   private static String SQLdelete = "DELETE FROM Lecture WHERE Lec_id=?";
   private static String SQLupdate = "UPDATE Lecture SET Lec_name=?,Sub_id=? WHERE Lec_id=?"; 
}
