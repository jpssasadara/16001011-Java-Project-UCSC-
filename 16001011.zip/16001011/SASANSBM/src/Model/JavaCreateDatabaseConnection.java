
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JavaCreateDatabaseConnection {
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static final String CONN = "jdbc:mysql://localhost/nsbmf";
    
    public static Connection getconnection()throws SQLException{
        return DriverManager.getConnection(CONN,USERNAME,PASSWORD);
    }


}