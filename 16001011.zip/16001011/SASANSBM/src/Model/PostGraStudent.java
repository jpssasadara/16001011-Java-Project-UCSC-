
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class PostGraStudent extends Student {
    private String Degree;
    private String University;
    private final String SQLAddStudent = "INSERT INTO StudentPost(Stu_id,F_name,L_name,Gmail,Gender,Dob,Address,Degree,University,Con_number,Reg_DegreeId)"+"VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    private final String SQLUpadateStudent = "UPDATE StudentPost SET F_name=?,L_name=?,Gmail=?,Gender=?,Dob=?,Address=?,Degree=?,University=?,Con_number=?,Reg_DegreeId=? WHERE Stu_id= ?";
    private final String SQLDeleteStudent = "DELETE FROM  StudentPost WHERE Stu_id=?";
    
     public PostGraStudent(String Stu_id,String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Con_number,String Reg_DegreeId,String Degree,String University){
       super(Stu_id,F_name,L_name,Gmail,Gender,Dob,Address,Con_number,Reg_DegreeId);
        this. Degree= Degree;
        this.University=University;
    }
    public PostGraStudent(){
        
    }
    public String get_Degree(){
       return Degree;
   }
   public void Set_Degree(String Degree){
       this.Degree=Degree;
   }
   
    public String get_University(){
       return University;
   }
   public void Set_University(String University){
       this.University=University;
   }
   
   public void AddStudent(String Stu_id,String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Degree,String University,String Con_number,String Reg_DegreeId ) throws SQLException{
      Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLAddStudent);
            stmt.setString(1, Stu_id);
            stmt.setString(2, F_name);
            stmt.setString(3, L_name);
            stmt.setString(4, Gmail);
            stmt.setString(5, Gender);
            stmt.setString(6, Dob);
            stmt.setString(7, Address);
            stmt.setString(8, Degree);
            stmt.setString(9, University);
            stmt.setString(10, Con_number);
            stmt.setString(11,Reg_DegreeId);
            
            stmt.execute();  
   }
   
  public void UpdateStudent(String F_name,String L_name,String Gmail,String Gender,String Dob,String Address,String Degree,String University,String Con_number,String Reg_DegreeId,String Stu_id) throws SQLException{
       
         Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLUpadateStudent);
            
            stmt.setString(1, F_name);
            stmt.setString(2, L_name);
            stmt.setString(3, Gmail);
            stmt.setString(4, Gender);
            stmt.setString(5, Dob);
            stmt.setString(6, Address);
            stmt.setString(7, Degree);
            stmt.setString(8, University);
            stmt.setString(9, Con_number);
            stmt.setString(10,Reg_DegreeId);
            stmt.setString(11, Stu_id);
             
            
            stmt.execute();
        
    }
  
  public void DeleteStudent(String Stu_id) throws SQLException{
        Connection conn = JavaCreateDatabaseConnection.getconnection();
            PreparedStatement stmt = conn.prepareStatement(SQLDeleteStudent);
             stmt.setString(1,Stu_id);
            
            stmt.execute();
    }
}
