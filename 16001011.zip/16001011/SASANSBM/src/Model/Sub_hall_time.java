
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Sub_hall_time {
    
    public Sub_hall_time(String Sub_id,String H_id,String Start_time,String End_time,String Day){
        this.Sub_id=Sub_id;
        this.Start_time=Start_time;
        this.Day=Day;
        this.H_id=H_id;
        this.End_time=End_time;
    }
   
    public String getSub_id() {
        return Sub_id;
    }

    
    public void setSub_id(String Sub_id) {
        this.Sub_id = Sub_id;
    }

   
    public String getH_id() {
        return H_id;
    }

    public void setH_id(String H_id) {
        this.H_id = H_id;
    }

   
    public String getStart_time() {
        return Start_time;
    }

   
    public void setStart_time(String Start_time) {
        this.Start_time = Start_time;
    }

   
    public String getEnd_time() {
        return End_time;
    }

   
    public void setEnd_time(String End_time) {
        this.End_time = End_time;
    }

   
    public String getDay() {
        return Day;
    }

   
    public void setDay(String Day) {
        this.Day = Day;
    }
    
    public static void insert(String Sub_id,String H_id,String Start_time,String End_time,String Day){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert);
           
            stmt.setString(1,Sub_id);
            stmt.setString(2,H_id);
            stmt.setString(3,Start_time);
            stmt.setString(4,End_time);
            stmt.setString(5,Day);
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
    public static void delete(String Sub_id,String H_id){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete);
           
            stmt.setString(1,Sub_id);
            stmt.setString(2,H_id);
            
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
    
    public static void update(String Sub_id,String H_id,String Start_time,String End_time,String Day){
        Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLupdate);
           
            
            stmt.setString(1,Start_time);
            stmt.setString(2,End_time);
            stmt.setString(3,Day);
            stmt.setString(4,Sub_id);
            stmt.setString(5,H_id);
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
   private String Sub_id;
   private String H_id;
   private String Start_time;
   private String End_time;
   private String Day;
   private static String SQLinsert = "INSERT INTO Sub_hall_time(Sub_id,H_id,Start_time,End_time,Day)"+"VALUES(?,?,?,?,?)";
   private static String SQLdelete = "DELETE FROM Sub_hall_time WHERE Sub_id=? AND H_id=?";
   private static String SQLupdate = "UPDATE Sub_hall_time SET Start_time=?,End_time=?,Day=? WHERE Sub_id=? AND H_id=?";
}
