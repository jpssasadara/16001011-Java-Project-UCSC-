
package Model;

import Model.JavaCreateDatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class LecHall {

   public LecHall(String H_id){
       this.H_id=H_id;
   }
    public String getH_id() {
        return H_id;
    }

    public void setH_id(String H_id) {
        this.H_id = H_id;
    }
    public static void hall_insert(String H_id){
       Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLinsert);
           
            stmt.setString(1,H_id) ;
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }
    }
    public static void hall_delete(String H_id){
      Connection conn;
       PreparedStatement stmt;
       try{
       conn = JavaCreateDatabaseConnection.getconnection();
       stmt = conn.prepareStatement(SQLdelete);
           
            stmt.setString(1,H_id) ;
           
            stmt.execute();
            conn.close();
            stmt.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e);
            }  
    }
  private String H_id; 
  private static  String SQLinsert = "INSERT INTO Lechall(H_id)"+"VALUES(?)";
  private static String SQLdelete = "DELETE FROM Lechall WHERE H_id=?";
}
