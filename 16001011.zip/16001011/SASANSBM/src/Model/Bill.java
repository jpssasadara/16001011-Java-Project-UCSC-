
package Model;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author suravi
 */
public class Bill {
    public static void prntBill(String TotalCredit,String TotalFee, ArrayList subjects,String StId,String yer) throws DocumentException, FileNotFoundException, SQLException{
         Document document = new Document(PageSize.A4, 50, 50, 50, 50);
            String billnum=StId.concat(yer).concat(TotalCredit).concat(TotalFee);
            String add = StId.concat(yer).concat(TotalCredit).concat(TotalFee).concat(".pdf");
            //String address="C:\\Users\\suravi\\Desktop\\project 2\\CreatePDF\\".concat(add);
            String address="C:\\Users\\suravi\\Desktop\\project 2\\SASANSBM\\".concat(add);
            PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(address));
            document.open();
        
        
            Anchor anchorTarget = new Anchor("NSBM GREEN UNIVERSITY ----------INVOICE ---------- NSBM GREEN UNIVERSITY");
            anchorTarget.setName("BackToTop");
            Paragraph paragraph1 = new Paragraph();
            paragraph1.setSpacingBefore(50);
            paragraph1.add(anchorTarget);
            document.add(paragraph1);
            document.add(new Paragraph("\t \t \t\t\t\tNSBM GREEN UNIVERSITY ", FontFactory.getFont(FontFactory.COURIER, 22, Font.BOLD, new CMYKColor(0, 255, 0, 0))));
       
            Date dnow = new Date();
            //SimpleDateFormat ft = new SimpleDateFormat("E yyyy.MM.dd 'at hh:mm:ss a zzz");
            //String todate =ft.format(dnow);
            
            Anchor anchorTarget2 = new Anchor("\n \n BILL NUMBER = "+billnum);
            Anchor anchorTarget3 = new Anchor("             DATE = "+ dnow+"\n\n");
            
            String SubName;
            String Credit;
            String fee;
            ResultSet rs=null;
            StringBuffer buffer = new StringBuffer();
            for(int i = 0; i< subjects.size();i++){
               
                rs=GetCreditsFees.Values(subjects.get(i).toString().substring(subjects.get(i).toString().indexOf("(") + 1, subjects.get(i).toString().indexOf(")")));
                while(rs.next()){
                    //System.out.println(rs.getString("Sub_name"));
                    buffer.append(i+1+") "+rs.getString("Sub_name")+"\n\n  <><><><><><><><><><><><> "+rs.getString("Sub_credits")+"  Credits  <><><><><><><>"+rs.getString("Sub_fee")+"/= \n");
                }
            }
            
             Anchor anchorTarget4 = new Anchor(buffer.toString());
             String finalone ="\n===================================================";
             
             String finaltwo ="\n      Total Credit       "+TotalCredit+"    Amount   "+TotalFee+"/=";
             String finalThree ="\n===================================================";
             String finalfour ="\n===================================================";  
              Anchor anchorTarget5 = new Anchor(finalone);
               Anchor anchorTarget6 = new Anchor(finaltwo);
                Anchor anchorTarget7 = new Anchor(finalThree);
                 Anchor anchorTarget8 = new Anchor(finalfour);
             
            Paragraph paragraph2 = new Paragraph();
            paragraph2.add(anchorTarget2);
            paragraph2.add(anchorTarget3);
            paragraph2.add(anchorTarget4);
            paragraph2.add(anchorTarget5);
            paragraph2.add(anchorTarget6);
            paragraph2.add(anchorTarget7);
            paragraph2.add(anchorTarget8);
            document.add(paragraph2);
            document.add(new Paragraph("\nTHANK YOU !!   "+StId+" was Registered for above subject ", FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, new CMYKColor(0, 255, 0, 0))));
            document.add(new Paragraph("\n       $$$$$$$  Paid   $$$$$$$  ", FontFactory.getFont(FontFactory.COURIER, 22, Font.BOLD, new CMYKColor(47, 28, 25, 0))));
            document.add(new Paragraph("\n \n Signature    =>> -------------------------------------------------", FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, new CMYKColor(42, 52, 12, 65))));
            document.close();
    }
}
