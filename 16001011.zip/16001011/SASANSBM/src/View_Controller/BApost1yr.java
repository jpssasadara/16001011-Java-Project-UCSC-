
package View_Controller;

import Model.Bill;
import Model.GetCreditsFees;
import Model.Student;
import com.itextpdf.text.DocumentException;
import java.awt.event.ItemEvent;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class BApost1yr extends javax.swing.JDialog {

    
    public BApost1yr(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        getContentPane().setBackground(new java.awt.Color(0,0,0));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jCheckBox16 = new javax.swing.JCheckBox();
        jCheckBox21 = new javax.swing.JCheckBox();
        jCheckBox22 = new javax.swing.JCheckBox();
        jLabel13 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("StudentId");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Year");

        jPanel2.setBackground(new java.awt.Color(8, 83, 8));

        jCheckBox1.setText("Strategic Cost Analysis  (ba4)");
        jCheckBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox1ItemStateChanged(evt);
            }
        });

        jCheckBox2.setText("Business Economics  (ba1)");
        jCheckBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox2ItemStateChanged(evt);
            }
        });

        jCheckBox3.setText("Enterprise Management  (ba2)");
        jCheckBox3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox3ItemStateChanged(evt);
            }
        });

        jCheckBox4.setText("Managing Information Systems  (ba3)");
        jCheckBox4.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox4ItemStateChanged(evt);
            }
        });

        jLabel5.setText("Compulsory Subjects");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox4)
                            .addComponent(jCheckBox3)
                            .addComponent(jCheckBox2)
                            .addComponent(jCheckBox1)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jCheckBox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox1)
                .addContainerGap(167, Short.MAX_VALUE))
        );

        jButton1.setText("UPdate");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Print Bill");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(37, 37, 37))
        );

        jPanel7.setBackground(new java.awt.Color(8, 83, 8));

        jCheckBox16.setText("Business Ethics and Sustainability  (ba5)");
        jCheckBox16.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox16ItemStateChanged(evt);
            }
        });

        jCheckBox21.setText("Accounting for Decision Makers  (ba6)");
        jCheckBox21.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox21ItemStateChanged(evt);
            }
        });

        jCheckBox22.setText("Residential Workshop  (ba7)");
        jCheckBox22.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox22ItemStateChanged(evt);
            }
        });

        jLabel13.setText("Compulsory Subjects");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox22)
                            .addComponent(jCheckBox21)
                            .addComponent(jCheckBox16)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jCheckBox16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox22)
                .addContainerGap(196, Short.MAX_VALUE))
        );

        jButton5.setText("UPdate");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Add");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton4.setText("Print Bill");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5)
                    .addComponent(jButton6)
                    .addComponent(jButton4))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("                                                          Semester 1");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("                                                          Semester 2");

        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Credits");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("0");

        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Fees");

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(86, 86, 86)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField2)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel19)
                        .addGap(57, 57, 57)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(jLabel21)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(60, 60, 60))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(jLabel20)
                            .addComponent(jLabel19))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox2ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist.add(jCheckBox2.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba1");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist.remove(jCheckBox2.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba1");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox2ItemStateChanged

    private void jCheckBox3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox3ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist.add(jCheckBox3.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba2");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist.remove(jCheckBox3.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba2");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox3ItemStateChanged

    private void jCheckBox4ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox4ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist.add(jCheckBox4.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba3");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist.remove(jCheckBox4.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba3");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox4ItemStateChanged

    private void jCheckBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox1ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist.add(jCheckBox1.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba4");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist.remove(jCheckBox1.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba4");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox1ItemStateChanged

    private void jCheckBox16ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox16ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist2.add(jCheckBox16.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba5");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist2.remove(jCheckBox16.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba5");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox16ItemStateChanged

    private void jCheckBox21ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox21ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
           ResultSet rs=GetCreditsFees.Values("ba6");
           arrlist2.add(jCheckBox21.getText().toString());
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist2.remove(jCheckBox21.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba6");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox21ItemStateChanged

    private void jCheckBox22ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox22ItemStateChanged
         if(evt.getStateChange() == ItemEvent.SELECTED){
             arrlist2.add(jCheckBox22.getText().toString());
           ResultSet rs=GetCreditsFees.Values("ba7");
           try {
               rs.next();
               countcredits=countcredits+rs.getInt("Sub_credits");
               countfees=countfees+rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
       }
        else if(evt.getStateChange() == ItemEvent.DESELECTED){
            arrlist2.remove(jCheckBox22.getText().toString());
            ResultSet rs=GetCreditsFees.Values("ba7");
           try {
               rs.next();
               countcredits=countcredits-rs.getInt("Sub_credits");
               countfees=countfees-rs.getInt("Sub_fee");
               rs.close();
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
        }
      jLabel20.setText(Integer.toString(countcredits));  
      jLabel22.setText(Integer.toString(countfees));
    }//GEN-LAST:event_jCheckBox22ItemStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         for(int counter = 0;counter <arrlist.size();counter++){
           
           try {
             Student.Enroll_Subject(arrlist.get(counter), jTextField1.getText(), jTextField2.getText(), "1");
              
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       for(int counter = 0;counter <arrlist2.size();counter++){
           
           try {
             Student.Enroll_Subject(arrlist2.get(counter), jTextField1.getText(), jTextField2.getText(), "2");
              
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         Student.Delect_Enrollment(jTextField1.getText(), jTextField2.getText(), "1");
       for(int counter = 0;counter <arrlist.size();counter++){
           
           try {
             Student.Enroll_Subject(arrlist.get(counter), jTextField1.getText(), jTextField2.getText(), "1");
              
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        Student.Delect_Enrollment(jTextField1.getText(), jTextField2.getText(), "2");
       for(int counter = 0;counter <arrlist2.size();counter++){
           
           try {
             Student.Enroll_Subject(arrlist2.get(counter), jTextField1.getText(), jTextField2.getText(), "2");
              
           } catch (SQLException ex) {
               Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         try {
            Bill.prntBill(Integer.toString(countcredits),Integer.toString(countfees) ,arrlist,jTextField1.getText(),jTextField2.getText());
        } catch (DocumentException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
         try {
            Bill.prntBill(Integer.toString(countcredits),Integer.toString(countfees) ,arrlist2,jTextField1.getText(),jTextField2.getText());
        } catch (DocumentException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ComputerScience1yr.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    
     ArrayList<String> arrlist = new ArrayList<String>();
    ArrayList<String> arrlist2 = new ArrayList<String>();
    private int countcredits = 0;
    private int countfees = 0;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox16;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox21;
    private javax.swing.JCheckBox jCheckBox22;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
