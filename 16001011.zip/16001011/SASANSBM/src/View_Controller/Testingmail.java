
package View_Controller;

import Model.Email;
import Model.Student;
import java.sql.SQLException;


public class Testingmail {

    public static void main(String arg[]) throws SQLException {
        //System.out.println(Student.Get_Assignment_Result("st1"));
        Email.sendmail(Student.Get_Assignment_Result("st1"),"st1");
        System.out.println(Student.getEmailAddress("st"));
       /* try{
            if(1==2){
                
                System.out.println("1");
            }
            else{
                System.out.println("2");
            }
        }
        catch(Exception e){
            System.out.println("3");
        }*/
    }
}
