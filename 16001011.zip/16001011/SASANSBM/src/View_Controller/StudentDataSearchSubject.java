
package View_Controller;

import Model.JavaCreateDatabaseConnection;
import Model.StudentEnrolledSubject_forJtable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;


public class StudentDataSearchSubject extends javax.swing.JFrame {

    public StudentDataSearchSubject() throws SQLException {
        initComponents();
        getContentPane().setBackground(new java.awt.Color(0,0,0));
        findUsers();
       
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setText("Student Id");

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jButton1)
                .addGap(317, 317, 317))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 706, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//Student Data Search Subject View
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            /*StudentDataSearchSubjectView gui = new  StudentDataSearchSubjectView(StudentDataSearchSubject.this,true);
            gui.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            gui.setTitle("Student Data Search Subject View");
            gui.setVisible(true); */
            findUsers();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDataSearchSubject.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed
    private ArrayList<StudentEnrolledSubject_forJtable> Listsubject(String stid) throws SQLException{
        ArrayList<StudentEnrolledSubject_forJtable> List = new ArrayList<StudentEnrolledSubject_forJtable>();
        String SQL="SELECT E.Level_no,E.Semester_no,E.Sub_id,S.Sub_name,S.Sub_credits,S.Sub_fee FROM enrollesubject E INNER JOIN Subject S ON E.Sub_id=S.Sub_id WHERE E.Stu_id=?";
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        /* private String level_no;
    private String sem_num;
    private String Sub_id;
    private String Sub_name;
    private String Num_Credit;
    private String fees;*/
        try{
           conn = JavaCreateDatabaseConnection.getconnection();
           stmt=conn.prepareStatement(SQL);
           stmt.setString(1,stid);
           rs=stmt.executeQuery();
           while(rs.next()){
               StudentEnrolledSubject_forJtable data = new StudentEnrolledSubject_forJtable(
                       rs.getString("Level_no"),
                       rs.getString("Semester_no"),
                       rs.getString("Sub_id"),
                       rs.getString("Sub_name"),
                       rs.getString("Sub_credits"),
                       rs.getString("Sub_fee")
                       );
               List.add(data);
           }
       }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return List;
    }
    // function to display data in jtable
    public void findUsers() throws SQLException
    {
        ArrayList<StudentEnrolledSubject_forJtable> data = Listsubject(jTextField1.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"Level Number","Semester Number","Subject Id","        Subject Name       ","Credits","Fees"});
        Object[] row = new Object[6];
        
        for(int i = 0; i < data.size(); i++)
        {
            row[0] = data.get(i).getLevel_no();
            row[1] = data.get(i).getSem_num();
            row[2] = data.get(i).getSub_id();
            row[3] = data.get(i).getSub_name();
            row[4] = data.get(i).getNum_Credit();
            row[5] = data.get(i).getFees();
            model.addRow(row);
        }
       jTable1.setModel(model);
        
       
    }
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
