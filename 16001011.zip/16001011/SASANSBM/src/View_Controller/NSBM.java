
package View_Controller;


public class NSBM {

    
    public static void main(String[] args) {
     
    }
    
}
